FastChargingPileNum = 2
TrickleChargingPileNum = 3
WaitingAreaSize = 6
ChargingQueueLen = 2

PeakRate = 1.0
NormalRate = 0.7
OffPeakRate = 0.4
ServiceFeeRate = 0.8
